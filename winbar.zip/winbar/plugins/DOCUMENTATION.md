# **Plugins**

A plugin for Winbar is any executable file found anywhere in the "$HOME/.config/winbar/plugins" directory that ends with ".plugin". 

Winbar will execute any such file on program start and have a dialogue with it via text. That means that you can make your plugin in any languague you want it, be it, bash, python, c++, go, or anything else, as long as it can read text input, and output text.

By "plugin" we don't mean arbritary mods to Winbar, instead we mean the ability to add icons to the system tray like how the volume icon opens the volume menu, or the battery icon opens the battery menu. Plugins let you add your own buttons which can create their own menu's.

## **Core loop**

Your program should read in input and watch for messages from Winbar.

For example, in bash, you'd do something like:

```bash
#!/bin/bash

while read line; do
  case $line in
  "program_start")
    ;;
  "program_end")
    exit
    ;;
  "window_shown")
    ;;
  "window_closed")
    ;;
  esac
done
```

 > This program reads input from Winbar into the "line" variable and then checks which message it was and does _something_ based on it.

## **Basic messages from Winbar to your plugin**

| Message | Description |
| ------- | ----------- |
| **program_start** | Sent to you when winbar launches (A good time to create the ui)
| **program_end** | Sent to you when winbar is going to shutdown in case you need to do some cleanup
| **window_shown** | Sent to you right before the window is shown
| **window_closed** | Sent to you right before the window is closed


## **Setting an icon for your plugin**

You can set the icon your plugin uses at any time (and you can change it at any time) using the message **set_icon** or **set_text_as_icon**. In bash you'd set the icon as follows:

```bash
#!/bin/bash

while read line; do
  case $line in
  "program_start")
    echo "set_icon \"vlc\""
    ;;
  esac
done
```

You'll notice that all you have to do is print out some text with "echo." Winbar will read your programs output and interpret the command. You'll also notice "vlc" is surrounded by quotes. Quotes are not optional.

**set_icon** should be passed in a string which is the name of the icon you wish to set. These names are from the icon themes you have installed.

**set_icon_text** should be passed in a string which it will use as the icon itself. (This is useful for plugins which want to use Windows 10 icons that come from the Segoe MDL2 font. In fact, this is where the volume icon, battery icon, wifi icon, and so on come from. You can find a non exhaustive list at https://learn.microsoft.com/en-us/windows/apps/design/style/segoe-ui-symbol-font or you can load $HOME/.config/winbar/fonts/SegoeMDL2Assets.ttf into fontforge and scroll all the way to the bottom and look at all the options available. You'd then have to pass in the unicode character to **set_icon_text**)

```c++
// In C++, setting the icon as the lock from: https://learn.microsoft.com/en-us/windows/apps/design/style/segoe-ui-symbol-font
printf("set_text_as_icon \"\uE72E\"\n");
```

**set_text_icon_color** should be passed in a string in the format "#AARRGGBB" representing the color you'd like to set the **icon_text** (Not you don't *have* to call this. By default it's the same color as the other icons in the system tray)

## **Making a UI**

After setting your plugins icon, you also need to create an interface to show to the user. There are a few nodes available for you to use like lables, and buttons, but before creating them you have to call **ui_start** first, and then **ui_end** when you're done.

The following is a simple example.

```bash
#!/bin/bash

while read line; do
  case $line in
  "program_start")
    echo "set_icon \"vlc\""

    echo "ui_start";

    echo "type=\"label\", text=\"This is a label!\"";
    echo "type=\"button\", text=\"And this is a button.\"";
    
    # Make a combobox and give it the name "Test Combo"
    # @Notice that the items property is a list of items separated by colons
    echo "type=\"combobox\", name=\"Test Combo\" items=\"Option 1: Option 2: Option 3\"";

    # Start laying out items horizontally
    echo "layout_horizontal"

    echo "type=\"button\", name=\"Test Name\", text=\"Button A.\"";
    
    # Make a filler to seperate the two buttons by setting the width property to 10
    echo "type=\"filler\", width=\"10\"";

    # Make a button and set the height property to 100
    echo "type=\"button\", text=\"Button B.\", height=\"100\"";
    
    # Stop laying out items horizontally
    echo "layout_pop";

    echo "ui_end";
    ;;

  # Winbar will send a message to the plugin when the user clicks a button in the following format
  # All you need to know is the name button, or label, or combobox, etc.
  "name=\"Test Name\", when_clicked=")
    # Change the text property of the button named "Test Name"
    echo "name=\"Test Name\", text=\"Button A was clicked!\"";
    ;;
  
  # Winbar will send a message to the plugin when the user selects an item in a combobox in the following format
  # All you need to know is the name of the combox
  "name=\"Test Combo\", when_selection=")
    # make a request to winbar for the items property of the combobox named "Test Combo"
    echo "name\"Test Combo\", items="

    # read the response into line
    read line
    ;;
  
  esac
done
```

You can see all this happens on **program_start** and that **set_icon** is called first. Then **ui_start**. 